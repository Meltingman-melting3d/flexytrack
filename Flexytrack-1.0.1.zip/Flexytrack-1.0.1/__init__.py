bl_info = {
    "name": "FlexyTrack",
    "author": "Georges Mignot, Emmanuel Boyer (translation, documentation, UI, debug)",
    "version": (1, 0, 1),
    "blender": (4, 2, 0),
    "location": "View3D > Sidebar > FlexyTrack",
    "description": "Automatically apply chained Damped Track constraints from the active bone descendants",
    "category": "Animation",
    "support": "COMMUNITY",
}

import bpy
from bpy.types import Operator, Panel, PropertyGroup
from bpy.props import FloatProperty, PointerProperty, BoolProperty, EnumProperty, StringProperty

ADDON_TRANSLATION_DOMAIN = __package__


class DelayedBonesProperties(PropertyGroup):
    influence_start: FloatProperty(
        name="Global Flexibility",
        description="Base influence value used by the selected falloff mode",
        default=0.8,
        min=0.0,
        max=1.0,
    )

    falloff_mode: EnumProperty(
        name="Falloff Mode",
        description="Influence distribution along the full chain",
        items=[
            ('LINEAR', "Linear", "Linear falloff across the whole chain"),
            ('EXPONENTIAL', "Exponential", "Exponential falloff across the whole chain"),
            ('CONSTANT', "Constant", "Same influence on the whole chain"),
        ],
        default='LINEAR',
    )

    decay_power: FloatProperty(
        name="Decay Power",
        description="Used in Exponential mode only. Higher values = faster falloff",
        default=2.0,
        min=0.1,
        max=10.0,
        precision=2,
    )

    show_help: BoolProperty(
        name="Help / Instructions",
        default=False,
        description="Show or hide instructions"
    )


def get_bone_depth(bone):
    depth = 0
    parent = bone.parent
    while parent:
        depth += 1
        parent = parent.parent
    return depth


def collect_descendants_chain(active_bone):
    descendants = list(active_bone.children_recursive)
    bones = [active_bone] + descendants
    bones.sort(key=get_bone_depth)
    return bones


def compute_influence(props, index, total_links):
    if total_links <= 1:
        return props.influence_start

    if props.falloff_mode == 'CONSTANT':
        factor = 1.0
    else:
        progress = index / (total_links - 1)

        if props.falloff_mode == 'LINEAR':
            factor = 1.0 - progress
        else:
            factor = (1.0 - progress) ** props.decay_power

    influence = props.influence_start * factor
    return max(0.0, min(1.0, influence))


class OBJECT_OT_apply_preset_delayed_bones(Operator):
    bl_idname = "object.apply_preset_delayed_bones"
    bl_label = "Apply Preset"
    bl_description = "Apply a predefined preset to the addon settings"
    bl_options = {'REGISTER', 'UNDO'}

    preset_name: StringProperty()

    def execute(self, context):
        props = context.scene.delayed_bones

        if self.preset_name == "FISH_PROPULSION":
            props.influence_start = 0.78
            props.falloff_mode = 'EXPONENTIAL'
            props.decay_power = 1.0
            self.report({'INFO'}, "Preset applied: Fish Propulsion")
            return {'FINISHED'}

        if self.preset_name == "OCTOPUS":
            props.influence_start = 0.92
            props.falloff_mode = 'EXPONENTIAL'
            props.decay_power = 0.3
            self.report({'INFO'}, "Preset applied: Octopus")
            return {'FINISHED'}

        if self.preset_name == "ROPE":
            props.influence_start = 0.9
            props.falloff_mode = 'CONSTANT'
            props.decay_power = 2.0
            self.report({'INFO'}, "Preset applied: Rope")
            return {'FINISHED'}

        self.report({'WARNING'}, f"Unknown preset: {self.preset_name}")
        return {'CANCELLED'}


class OBJECT_OT_clear_delayed_bones(Operator):
    bl_idname = "object.clear_delayed_bones"
    bl_label = "Clear Damped Track"
    bl_description = "Removes all 'DelayedTrack' constraints from active bone and its descendants"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        active_object = context.active_object

        if not (active_object and active_object.type == 'ARMATURE' and context.mode == 'POSE'):
            self.report({'ERROR'}, "Pose Mode required")
            return {'CANCELLED'}

        active_bone = context.active_pose_bone
        if not active_bone:
            self.report({'ERROR'}, "Select an active bone")
            return {'CANCELLED'}

        bones = collect_descendants_chain(active_bone)

        count = 0
        for bone in bones:
            for constraint in list(bone.constraints):
                if constraint.type == 'DAMPED_TRACK' and constraint.name == "DelayedTrack":
                    bone.constraints.remove(constraint)
                    count += 1

        self.report({'INFO'}, f"Constraints removed: {count}")
        return {'FINISHED'}


class OBJECT_OT_apply_delayed_bones(Operator):
    bl_idname = "object.apply_delayed_bones"
    bl_label = "Apply Damped Track"
    bl_description = "Apply delay logic from active bone through all descendants"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        props = context.scene.delayed_bones
        armature = context.active_object

        if not (armature and armature.type == 'ARMATURE' and context.mode == 'POSE'):
            self.report({'ERROR'}, "Pose Mode required")
            return {'CANCELLED'}

        active_bone = context.active_pose_bone
        if not active_bone:
            self.report({'ERROR'}, "Select an active bone")
            return {'CANCELLED'}

        bones = collect_descendants_chain(active_bone)

        if len(bones) < 2:
            self.report({'ERROR'}, "Active bone must have at least 1 child bone")
            return {'CANCELLED'}

        branching = any(len(b.children) > 1 for b in bones[:-1])
        if branching:
            self.report({'WARNING'}, "Branching detected: best results are with a single chain")

        for bone in bones:
            for constraint in list(bone.constraints):
                if constraint.type == 'DAMPED_TRACK' and constraint.name == "DelayedTrack":
                    bone.constraints.remove(constraint)

        applied_count = 0
        total_links = len(bones) - 1

        for i in range(total_links):
            bone = bones[i]
            target_bone = bones[i + 1]
            influence = compute_influence(props, i, total_links)

            constraint = bone.constraints.new('DAMPED_TRACK')
            constraint.name = "DelayedTrack"
            constraint.target = armature
            constraint.subtarget = target_bone.name
            constraint.track_axis = 'TRACK_Y'
            constraint.influence = influence

            applied_count += 1

        self.report({'INFO'}, f"Applied on links: {applied_count}")
        return {'FINISHED'}


class VIEW3D_PT_flexytrack(Panel):
    bl_label = "FlexyTrack"
    bl_idname = "VIEW3D_PT_flexytrack"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "FlexyTrack"

    def draw(self, context):
        layout = self.layout
        props = context.scene.delayed_bones
        active_bone = context.active_pose_bone

        col = layout.column(align=True)
        col.prop(props, "influence_start")
        col.prop(props, "falloff_mode")

        if props.falloff_mode == 'EXPONENTIAL':
            col.prop(props, "decay_power")

        layout.separator()

        preset_box = layout.box()
        preset_col = preset_box.column(align=True)
        preset_col.label(text="Presets", icon='PRESET')

        op = preset_col.operator("object.apply_preset_delayed_bones", text="Fish", icon='FORCE_FORCE')
        op.preset_name = "FISH_PROPULSION"

        op = preset_col.operator("object.apply_preset_delayed_bones", text="Octopod", icon='ARMATURE_DATA')
        op.preset_name = "OCTOPUS"

        op = preset_col.operator("object.apply_preset_delayed_bones", text="Rope", icon='CURVE_DATA')
        op.preset_name = "ROPE"

        layout.separator()

        info_box = layout.box()
        info_col = info_box.column(align=True)
        if active_bone:
            chain_len = 1 + len(active_bone.children_recursive)
            info_col.label(text=f"Active Bone: {active_bone.name}", icon='BONE_DATA')
            info_col.label(text=f"Detected Descendants: {chain_len - 1}")
            info_col.label(text=f"Total Bones in Chain: {chain_len}")
        else:
            info_col.label(text="No active bone", icon='ERROR')

        layout.separator()

        ops = layout.column(align=True)
        ops.operator("object.apply_delayed_bones", icon='CONSTRAINT')
        ops.operator("object.clear_delayed_bones", icon='TRASH')

        layout.separator()

        icon = 'TRIA_DOWN' if props.show_help else 'TRIA_RIGHT'
        row = layout.row(align=True)
        row.prop(props, "show_help", icon=icon, emboss=False)

        if props.show_help:
            box = layout.box()
            col = box.column(align=True)
            col.label(text="How to use:", icon='FILE_TEXT')
            col.label(text="1. Select the root bone of the chain")
            col.label(text="2. Make sure it is the active bone")
            col.label(text="3. Choose a mode or use a preset")
            col.label(text="4. Click 'Apply Damped Track'")
            col.label(text="5. All descendants are processed automatically")
            col.label(text="6. Rope preset uses constant influence on all bones")
            col.label(text="7. Best results on a single chain")
            col.label(text="Note: French UI requires Blender interface language set to French")


translations = {
    "fr_FR": {
        ("*", "Global Flexibility"): "Souplesse globale",
        ("*", "Base influence value used by the selected falloff mode"): "Valeur d'influence de base utilisée par le mode de décroissance choisi",

        ("*", "Falloff Mode"): "Mode de décroissance",
        ("*", "Influence distribution along the full chain"): "Répartition de l'influence sur toute la chaîne",

        ("*", "Linear"): "Linéaire",
        ("*", "Linear falloff across the whole chain"): "Décroissance linéaire sur toute la chaîne",

        ("*", "Exponential"): "Exponentiel",
        ("*", "Exponential falloff across the whole chain"): "Décroissance exponentielle sur toute la chaîne",

        ("*", "Constant"): "Constant",
        ("*", "Same influence on the whole chain"): "Même influence sur toute la chaîne",

        ("*", "Decay Power"): "Puissance de décroissance",
        ("*", "Used in Exponential mode only. Higher values = faster falloff"): "Utilisé uniquement en mode exponentiel. Plus la valeur est élevée, plus la décroissance est rapide",

        ("*", "Help / Instructions"): "Aide / Mode d'emploi",
        ("*", "Show or hide instructions"): "Afficher ou masquer les instructions",

        ("*", "Apply Preset"): "Appliquer un preset",
        ("*", "Apply a predefined preset to the addon settings"): "Applique un preset prédéfini aux réglages de l'addon",

        ("*", "Presets"): "Presets",
        ("*", "Fish"): "Poisson propulsion",
        ("*", "Rope"): "Corde",

        ("*", "Clear Damped Track"): "Supprimer Damped Track",
        ("*", "Removes all 'DelayedTrack' constraints from active bone and its descendants"): "Supprime toutes les contraintes 'DelayedTrack' de l'os actif et de sa descendance",

        ("*", "Apply Damped Track"): "Appliquer Damped Track",
        ("*", "Apply delay logic from active bone through all descendants"): "Applique la logique de retard depuis l'os actif sur toute la descendance",

        ("*", "How to use:"): "Mode d'emploi :",
        ("*", "1. Select the root bone of the chain"): "1. Sélectionnez l'os racine de la chaîne",
        ("*", "2. Make sure it is the active bone"): "2. Assurez-vous qu'il s'agit de l'os actif",
        ("*", "3. Choose a mode or use a preset"): "3. Choisissez un mode ou utilisez un preset",
        ("*", "4. Click 'Apply Damped Track'"): "4. Cliquez sur 'Appliquer Damped Track'",
        ("*", "5. All descendants are processed automatically"): "5. Toute la descendance est traitée automatiquement",
        ("*", "6. Rope preset uses constant influence on all bones"): "6. Le preset corde utilise une influence constante sur tous les os",
        ("*", "7. Best results on a single chain"): "7. Meilleurs résultats sur une chaîne simple",
        ("*", "Note: French UI requires Blender interface language set to French"): "Note : l'interface française nécessite que la langue de Blender soit réglée sur français",

        ("*", "Pose Mode required"): "Le mode Pose est requis",
        ("*", "Select an active bone"): "Sélectionnez un os actif",
        ("*", "Active bone must have at least 1 child bone"): "L'os actif doit avoir au moins un os enfant",
        ("*", "Branching detected: best results are with a single chain"): "Branchements détectés : meilleurs résultats avec une chaîne simple",
        ("*", "Constraints removed"): "Contraintes supprimées",
        ("*", "Applied on links"): "Appliqué sur les liens",
        ("*", "Active Bone"): "Os actif",
        ("*", "Detected Descendants"): "Descendants détectés",
        ("*", "Total Bones in Chain"): "Nombre total d'os dans la chaîne",
        ("*", "No active bone"): "Aucun os actif",

        ("*", "Preset applied: Fish Propulsion"): "Preset appliqué : Poisson propulsion",
        ("*", "Preset applied: Octopus"): "Preset appliqué : Octopode",
        ("*", "Preset applied: Rope"): "Preset appliqué : Corde",
    }
}


classes = (
    DelayedBonesProperties,
    OBJECT_OT_apply_preset_delayed_bones,
    OBJECT_OT_clear_delayed_bones,
    OBJECT_OT_apply_delayed_bones,
    VIEW3D_PT_flexytrack,
)


def register():
    bpy.app.translations.register(ADDON_TRANSLATION_DOMAIN, translations)
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.delayed_bones = PointerProperty(type=DelayedBonesProperties)


def unregister():
    if hasattr(bpy.types.Scene, "delayed_bones"):
        del bpy.types.Scene.delayed_bones
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    bpy.app.translations.unregister(ADDON_TRANSLATION_DOMAIN)
